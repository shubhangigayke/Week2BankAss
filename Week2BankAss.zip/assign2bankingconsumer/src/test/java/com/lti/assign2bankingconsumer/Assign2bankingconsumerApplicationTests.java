package com.lti.assign2bankingconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assign2bankingconsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
