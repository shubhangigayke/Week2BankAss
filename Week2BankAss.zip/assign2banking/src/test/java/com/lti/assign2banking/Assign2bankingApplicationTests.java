package com.lti.assign2banking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Assign2bankingApplicationTests {

	@Test
	void contextLoads() {
	}

}
