package com.lti.assign2bankingconsumer;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;

import com.lti.assign2bankingconsumer.controller.ConsumerControllerClient;

@SpringBootApplication 
@EnableDiscoveryClient
public class Assign2bankingconsumerApplication {

	public static void main(String[] args) throws RestClientException, IOException {
		ApplicationContext ctx= SpringApplication.run(Assign2bankingconsumerApplication.class, args);
		ConsumerControllerClient controllerClient=ctx.getBean(ConsumerControllerClient.class);
		System.out.println(controllerClient);
			controllerClient.getCustomers();
	}
	@Bean
	public  ConsumerControllerClient  consumerControllerClient()
	{
		return  new ConsumerControllerClient();
	}

}
